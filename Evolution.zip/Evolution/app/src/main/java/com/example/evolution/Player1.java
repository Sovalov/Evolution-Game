package com.example.evolution;

public class Player1 {
    static int cards[] = new int[3];
}
