package com.example.evolution;

public class animal {
    public boolean alive = true;
    public int hunger = 1;
    public boolean swimming = false;
    public boolean predator = false;
    public boolean fast = false;

}
