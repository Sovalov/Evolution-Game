package com.example.evolution;

public class Player2 {
    static int cards[] = new int[3];
}
