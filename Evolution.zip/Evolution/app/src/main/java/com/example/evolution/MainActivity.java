package com.example.evolution;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    int cards[] = new int[3];
    int rnd = 0;
    int sum = 0;
    int count = 1;
    int player = 0;
    ArrayList<animal> animals = new ArrayList<animal>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void GameButton(View view) {
        setContentView(R.layout.game);
        cards[0] = 5;
        cards[1] = 5;
        cards[2] = 5;
        Player1.cards[0] = 0;
        Player1.cards[1] = 0;
        Player1.cards[2] = 0;
        Player2.cards[0] = 0;
        Player2.cards[1] = 0;
        Player2.cards[2] = 0;
        sum = 0;
        Log.d("Колода","Переход в игру, колода и игроки обнулены");
    }

    public void GiveCard(View view){
        GiveCards(8, 9);
    }

    public void GiveCards(int first, int second){
        count = 0;
        sum = 0;
        player = 0;
        boolean stop = false;
        for (int i = 0; i < cards.length; i++){
            sum = sum + cards[i];
        }
        int subsumm = first + second;


        while (sum > 0 && subsumm > 0) {
            stop = false;
            count = 0;
            rnd = rand(sum - 1) + 1;
            for (int i = 0; rnd > cards[i]; i++) {
                rnd = rnd - cards[i];
                count = count + 1;
            }
            Log.d("Player","c" + count);
            cards[count] = cards[count] - 1;
            if (player == 0 && first > 0){
                Player1.cards[count] = Player1.cards[count]+1;
                player = 1;
                Log.d("Player","1" + String.valueOf(count+1));
                stop = true;
                first -= 1;
            }
            else{
                player = 1;
            }
            if (player == 1 && second > 0 && stop == false) {
                Player2.cards[count] = Player2.cards[count]+1;
                player = 0;
                Log.d("Player","2" + String.valueOf(count+1));
                second -= 1;
            }
            else{
                if (stop == false){
                        player = 0;
                }
            }
            subsumm = first + second;

            Log.d("Player","s" + subsumm);
            sum = sum -1;

        }
    }

    public void StartGame(View view){
        cards[0] = 5; //swimming
        cards[1] = 5; //predator
        cards[2] = 5; //fast
        Player1.cards[0] = 0;
        Player1.cards[1] = 0;
        Player1.cards[2] = 0;
        Player2.cards[0] = 0;
        Player2.cards[1] = 0;
        Player2.cards[2] = 0;
        sum = 0;
        Log.d("Колода","Колода пополнена");

    }

    public void createanimal (int crd){
        Player1.cards[card(crd)] = Player1.cards[card(crd)] - 1;
        //Log.d("DEBUG", "" + animals.get(i).i);

        animal Tom = new animal();
        animals.add(Tom);
    }

    public void addprop (int crd, int anim){
        if (card(crd) == 0){
            animals.get(anim).swimming = true;
        }
        if (card(crd) == 1){
            animals.get(anim).predator = true;
        }
        if (card(crd) == 2){
            animals.get(anim).fast = true;
        }
    }

    public static int rand(int max)
    {
        return (int) (Math.random() * ++max);
    }

    public int card(int num){
        int lcount = 0;
        for (int i = 0; num > Player1.cards[i]; i++) {
            num = num - Player1.cards[i];
            lcount = lcount + 1;
        }
        return lcount;
    }

    public void create (View view){
        createanimal(1);
    }

    public void add (View view){
        addprop(1, 0);
    }

    public void show (View view){
        Log.d("Колода",String.valueOf(Player1.cards[0]) + ' ' + String.valueOf(Player1.cards[1]) + ' ' + String.valueOf(Player1.cards[2]));
        Log.d("Колода",String.valueOf(Player2.cards[0]) + ' ' + String.valueOf(Player2.cards[1]) + ' ' + String.valueOf(Player2.cards[2]));
    }

}
